Welche HTML für die HP verwenden?
=================================

Für die aktuelle datenbasierte Website bitte diese Datei verwenden:

  index.html

Wichtig:
- Diese index.html liest Inhalte aus:
    data/site-data.json
- Deshalb muss der Ordner data/ mit site-data.json neben index.html liegen.
- Lokal NICHT per Doppelklick testen, sondern über:
    website_lokal_ansehen.bat
  oder:
    python -m http.server 8000
- Auf GitHub Pages funktioniert das Laden der JSON-Datei normal.
- Die Pfade sind relativ:
    ./data/site-data.json
    images/...
    media/...
    audio/...
  Deshalb muss die Ordnerstruktur erhalten bleiben.
- Bilder aus dem ursprünglichen GitHub-Repo gehören in:
    images/
- Neue Konzertbilder gehören in:
    media/konzerte/
- Die Python-App schreibt in:
    data/site-data.json

Nicht verwechseln:
- Eine alte statische index.html enthält die Konzerttexte direkt im HTML.
- Die aktuelle Version lädt Konzerte/Vita/Medien dynamisch aus site-data.json.
