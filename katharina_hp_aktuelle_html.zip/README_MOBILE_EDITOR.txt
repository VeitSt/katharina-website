Katharina Website – mobile-freundlicher Offline-/Lokal-Editor
==============================================================

Start unter Windows:
1. ZIP entpacken.
2. In den entpackten Ordner gehen.
3. "starten_mobile_editor.bat" doppelklicken.
4. Der Browser öffnet den Editor unter http://localhost:8765/admin

Vom Handy im selben WLAN:
1. Auf dem PC "starten_mobile_editor.bat" laufen lassen.
2. Im schwarzen Fenster steht eine Adresse wie:
   http://192.168.178.xx:8765/admin
3. Diese Adresse am Handy im Browser öffnen.
4. Wichtig: PC und Handy müssen im gleichen WLAN sein.
   Falls es nicht geht, blockiert wahrscheinlich die Windows-Firewall.

Was wurde geändert?
- Der Editor ist jetzt eine mobile Web-Oberfläche statt einer engen Desktop-Maske.
- Große Textfelder.
- Vorhandene Konzerte antippen und direkt bearbeiten.
- Speichern-Button immer unten sichtbar.
- Bild-Upload kopiert Bilder automatisch nach media/konzerte/.
- "Veröffentlichen" ruft git add / commit / push auf.

Wichtige Dateien:
- index.html: dynamische Website, liest data/site-data.json.
- data/site-data.json: alle bearbeitbaren Inhalte.
- website_manager_mobile.py: lokaler Editor.
- index_static_backup.html: Sicherung der ursprünglichen statischen HTML-Datei.

Lokale Website ansehen:
- Entweder im Editor auf "Website ansehen" klicken.
- Oder "website_lokal_ansehen.bat" starten und http://localhost:8000 öffnen.

Hinweis:
Wenn die Website per Doppelklick als file:/// geöffnet wird, kann das Laden von
data/site-data.json blockiert werden. Deshalb immer über den lokalen Server testen.
