@echo off
title Katharina Website lokal ansehen

cd /d "%~dp0"

python -m http.server 8000

pause
