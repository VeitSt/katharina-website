Korrigierte index.html für Konzerte aus JSON
===========================================

Diese Version basiert auf deiner Original-HTML.

Beibehalten:
- Header
- Vita
- Repertoire
- Medien
- Unterricht
- Kontakt
- Originales Styling

Geändert:
- Der Konzertbereich lädt seine Inhalte aus:
    data/konzerte.json

Wichtig:
- Die Ordnerstruktur muss so bleiben:
    index.html
    data/konzerte.json
    images/
    media/konzerte/  (für neue Konzertbilder)
- Lokal bitte NICHT per Doppelklick testen.
  Stattdessen:
    python -m http.server 8000
  und dann öffnen:
    http://localhost:8000
- Auf GitHub Pages funktioniert der JSON-Load normal.
- Wenn die JSON nicht gefunden wird, bleibt eine Fallback-Liste im HTML sichtbar.
