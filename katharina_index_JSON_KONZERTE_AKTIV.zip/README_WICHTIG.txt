WICHTIG

Diese Version ist eindeutig markiert mit:

  JSON-KONZERTE-AKTIV

So prüfst du es:
1. index.html mit Notepad++ oder VS Code öffnen.
2. Strg+F drücken.
3. Nach 'JSON-KONZERTE-AKTIV' suchen.
4. Nach 'fetch("./data/konzerte.json' suchen.

Diese Datei lädt die Konzerte aus:

  data/konzerte.json

Bitte ersetze im GitHub-Ordner wirklich die vorhandene index.html durch DIESE index.html.
Nicht die alte index.html weiterverwenden.

Lokal testen:
  python -m http.server 8000
Dann:
  http://localhost:8000
