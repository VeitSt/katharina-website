Korrigierte Version: Konzerte aus JSON
=====================================

Diese index.html enthält die alten Inhalte, lädt aber den Konzertbereich aus:

  data/konzerte.json

Wichtig:
- Die Datei muss genau hier liegen:
    data/konzerte.json
- Lokal bitte über lokalen Server testen:
    python -m http.server 8000
  Dann im Browser:
    http://localhost:8000
- Nicht per Doppelklick öffnen, sonst blockiert der Browser ggf. das Laden der JSON.
- Auf GitHub Pages funktioniert der relative Pfad:
    ./data/konzerte.json
- Wenn die JSON nicht geladen werden kann, bleibt die Fallback-Liste im HTML sichtbar.
