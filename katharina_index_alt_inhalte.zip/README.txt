Neue index.html mit alten Inhalten
=================================

Diese Version übernimmt die alten Inhalte aus deiner bisherigen HTML:

- Header
- Vita
- Repertoire
- Medien
- Unterricht
- Kontakt

Nur der Konzertbereich ist dynamisch vorbereitet:

  data/konzerte.json

Wenn data/konzerte.json geladen werden kann, werden die Konzerte daraus angezeigt.
Wenn nicht, bleibt die alte Fallback-Liste im HTML sichtbar.

Wichtig:
- Lokal nicht per Doppelklick testen, sondern über lokalen Server:
    python -m http.server 8000
  oder mit deiner website_lokal_ansehen.bat.
- Auf GitHub Pages funktioniert das Laden der JSON-Datei.
- Der Testeintrag "XYCCSSASAAA" wurde nicht übernommen.
- Die Bilder müssen weiterhin im Ordner images/ liegen.
- Neue Konzertbilder können später z.B. in media/konzerte/ liegen.
